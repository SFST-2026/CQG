# Figures for journal submission

This directory contains the **final figure assets** to upload during submission.

## Figure X (numerical validation) — 3 single panels
Upload the **vector PDF** files as the masters (recommended by CQG), and optionally the 600‑dpi raster versions if requested.

- `figX_panelA_convergence.pdf`  (also: `figX_panelA_convergence.png`)
- `figX_panelB_epsratio.pdf`     (also: `figX_panelB_epsratio.png`)
- `figX_panelC_residuals.pdf`    (also: `figX_panelC_residuals.png`)

In the manuscript these are referenced as **Figure X(a–c)**.

## Regeneration (reproducible)
From the repository root:

```bash
python scripts/plot_figureX.py --data-dir data/examples --out-dir figures --observable Lambda14 --dpi 600
```

Provenance is written to `figures/plot_metadata.json` and mirrored in the Supplement PROVENANCE section.
